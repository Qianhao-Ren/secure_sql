import sqlite3

db_path = r"uploads\b20ca58d-9f0f-41d1-8392-afd78bdc86fc_employee_hire_evaluation.sqlite"
conn = sqlite3.connect(db_path)
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
print(cur.fetchall())
conn.close()