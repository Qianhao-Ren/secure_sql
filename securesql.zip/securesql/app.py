from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3
import os
import requests
import json
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)

# 配置
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['DB_METADATA_FILE'] = 'databases_metadata.json'  # 存储数据库元信息的文件

# 确保上传文件夹存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('static', exist_ok=True)

# 存储数据库信息
databases = {}

# API配置
API_CONFIG = {
    'api_type': 'lixiang',
    'model': 'azure-gpt-4_1',
    'base_url': 'https://chatgpt-o1-api.dev.fc.chj.cloud/v1/chat/completions',
    'api_key': os.getenv('API_KEY', 'YOUR_API_KEY'),  # 从环境变量读取或使用默认值
    'max_tokens': 8192,
    'temperature': 0.5
}

def save_databases_metadata():
    """保存数据库元信息到文件"""
    try:
        with open(app.config['DB_METADATA_FILE'], 'w', encoding='utf-8') as f:
            json.dump(databases, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"保存数据库元信息失败: {str(e)}")

def load_databases_metadata():
    """从文件加载数据库元信息"""
    global databases
    try:
        if os.path.exists(app.config['DB_METADATA_FILE']):
            with open(app.config['DB_METADATA_FILE'], 'r', encoding='utf-8') as f:
                databases = json.load(f)
                
            # 验证每个数据库文件是否仍然存在
            databases_to_remove = []
            for db_id, info in databases.items():
                if not os.path.exists(info['filepath']):
                    databases_to_remove.append(db_id)
                    print(f"数据库文件不存在，将移除: {info['filename']}")
            
            # 移除不存在的数据库
            for db_id in databases_to_remove:
                del databases[db_id]
            
            # 如果有变化，保存更新后的元信息
            if databases_to_remove:
                save_databases_metadata()
                
            print(f"成功加载 {len(databases)} 个数据库")
        else:
            print("没有找到数据库元信息文件，将创建新文件")
            databases = {}
            
    except Exception as e:
        print(f"加载数据库元信息失败: {str(e)}")
        databases = {}

def scan_and_repair_databases():
    """扫描uploads文件夹，修复可能丢失的数据库信息"""
    try:
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            return
            
        # 获取所有已知的文件路径
        known_files = {info['filepath'] for info in databases.values()}
        
        # 扫描uploads文件夹中的所有.db文件
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            if filename.endswith('.db'):
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                # 如果这个文件不在已知数据库中
                if filepath not in known_files:
                    try:
                        # 验证是否为有效的SQLite数据库
                        conn = sqlite3.connect(filepath)
                        cursor = conn.cursor()
                        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                        tables = cursor.fetchall()
                        conn.close()
                        
                        # 生成ID（尝试从文件名提取，否则生成新的）
                        if '_' in filename:
                            db_id = filename.split('_')[0]
                            # 验证是否为有效的UUID
                            try:
                                uuid.UUID(db_id)
                            except:
                                db_id = str(uuid.uuid4())
                        else:
                            db_id = str(uuid.uuid4())
                        
                        # 确保ID不重复
                        while db_id in databases:
                            db_id = str(uuid.uuid4())
                        
                        # 添加到数据库列表
                        databases[db_id] = {
                            'name': filename.replace('.db', ''),
                            'filename': filename,
                            'filepath': filepath,
                            'description': '自动恢复的数据库',
                            'tables': [table[0] for table in tables]
                        }
                        print(f"恢复数据库: {filename}")
                        
                    except Exception as e:
                        print(f"无法恢复数据库 {filename}: {str(e)}")
        
        # 保存更新后的元信息
        if databases:
            save_databases_metadata()
            
    except Exception as e:
        print(f"扫描数据库失败: {str(e)}")

def call_llm_api(messages):
    """调用LLM API"""
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {API_CONFIG["api_key"]}'
    }
    
    data = {
        'model': API_CONFIG['model'],
        'messages': messages,
        'temperature': API_CONFIG['temperature'],
        'max_tokens': API_CONFIG['max_tokens']
    }
    
    try:
        response = requests.post(
            API_CONFIG['base_url'],
            headers=headers,
            json=data,
            timeout=30
        )
        response.raise_for_status()
        
        result = response.json()
        return result['choices'][0]['message']['content']
    except requests.exceptions.RequestException as e:
        raise Exception(f"API调用失败: {str(e)}")

def select_database_by_rag(question):
    """使用RAG选择最合适的数据库"""
    if not databases:
        return None, "没有可用的数据库"
    
    # 构建数据库信息列表
    db_info_list = []
    for db_id, info in databases.items():
        db_info_list.append({
            'id': db_id,
            'name': info.get('name', info['filename']),
            'filename': info['filename'],
            'description': info.get('description', ''),
            'tables': info['tables']
        })
    
    # 构建RAG选择prompt
    rag_prompt = f"""
    用户问题：{question}
    
    可用的数据库列表：
    {json.dumps(db_info_list, ensure_ascii=False, indent=2)}
    
    请根据用户的问题，选择最适合回答该问题的数据库。
    选择时考虑：
    1. 数据库名称和描述与问题的相关性
    2. 数据库包含的表是否可能包含回答问题所需的数据
    
    请以JSON格式返回：
    {{
        "selected_db_id": "选中的数据库ID",
        "reason": "选择该数据库的原因"
    }}
    
    如果没有合适的数据库，返回：
    {{
        "selected_db_id": null,
        "reason": "没有找到适合回答该问题的数据库"
    }}
    """
    
    try:
        messages = [
            {"role": "system", "content": "你是一个数据库选择专家，能够根据用户问题选择最合适的数据库。"},
            {"role": "user", "content": rag_prompt}
        ]
        
        response_content = call_llm_api(messages)
        
        # 解析响应
        try:
            result = json.loads(response_content)
        except json.JSONDecodeError:
            import re
            json_match = re.search(r'\{.*?\}', response_content, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
            else:
                # 如果无法解析，选择第一个数据库
                result = {
                    "selected_db_id": list(databases.keys())[0],
                    "reason": "自动选择第一个数据库"
                }
        
        selected_db_id = result.get('selected_db_id')
        reason = result.get('reason', '')
        
        # 验证选择的数据库是否存在
        if selected_db_id and selected_db_id in databases:
            return selected_db_id, reason
        else:
            # 如果选择的数据库不存在，返回第一个
            return list(databases.keys())[0], "默认选择第一个数据库"
            
    except Exception as e:
        print(f"RAG选择错误: {str(e)}")
        # 出错时返回第一个数据库
        return list(databases.keys())[0], f"RAG选择出错，默认选择第一个数据库: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/upload', methods=['POST'])
def upload_database():
    """上传数据库文件和描述文本"""
    try:
        if 'database' not in request.files:
            return jsonify({'error': '没有找到数据库文件'}), 400
        
        db_file = request.files['database']
        name = request.form.get('name', '')
        description = request.form.get('description', '')
        
        if db_file.filename == '':
            return jsonify({'error': '没有选择文件'}), 400
        
        # 生成唯一ID
        db_id = str(uuid.uuid4())
        
        # 保存文件
        filename = secure_filename(db_file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{db_id}_{filename}")
        db_file.save(filepath)
        
        # 验证是否为有效的SQLite数据库
        try:
            conn = sqlite3.connect(filepath)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            conn.close()
        except:
            os.remove(filepath)
            return jsonify({'error': '无效的SQLite数据库文件'}), 400
        
        # 存储数据库信息
        databases[db_id] = {
            'name': name if name else filename,
            'filename': filename,
            'filepath': filepath,
            'description': description,
            'tables': [table[0] for table in tables]
        }
        
        # 保存元信息到文件
        save_databases_metadata()
        
        return jsonify({
            'success': True,
            'db_id': db_id,
            'name': databases[db_id]['name'],
            'filename': filename,
            'tables': databases[db_id]['tables']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/databases', methods=['GET'])
def list_databases():
    """列出所有已上传的数据库"""
    db_list = []
    for db_id, info in databases.items():
        db_list.append({
            'id': db_id,
            'name': info.get('name', info['filename']),
            'filename': info['filename'],
            'description': info.get('description', ''),
            'tables': info['tables']
        })
    return jsonify(db_list)

@app.route('/database/<db_id>', methods=['DELETE'])
def delete_database(db_id):
    """删除数据库"""
    try:
        if db_id not in databases:
            return jsonify({'error': '数据库不存在'}), 404
        
        # 删除文件
        filepath = databases[db_id]['filepath']
        if os.path.exists(filepath):
            os.remove(filepath)
        
        # 从内存中删除
        del databases[db_id]
        
        # 保存更新后的元信息
        save_databases_metadata()
        
        return '', 204
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/check_privacy', methods=['POST'])
def check_privacy():
    """检查问题是否涉及隐私"""
    try:
        data = request.json
        question = data.get('question', '')
        db_id = data.get('db_id', '')
        
        # 如果是自动选择模式，使用RAG选择数据库
        if db_id == 'auto' or db_id is None:
            db_id, selection_reason = select_database_by_rag(question)
            if not db_id:
                return jsonify({'error': '无法选择合适的数据库'}), 404
            
            # 在响应中包含选择的数据库信息
            selected_db_info = {
                'selected_db_id': db_id,
                'selected_db_name': databases[db_id].get('name', databases[db_id]['filename']),
                'selection_reason': selection_reason
            }
        else:
            if db_id not in databases:
                return jsonify({'error': '数据库不存在'}), 404
            selected_db_info = None
        
        db_info = databases[db_id]
        
        # 构建隐私检查的prompt
        privacy_prompt = f"""
        数据库描述和隐私信息：
        {db_info['description']}
        
        用户问题：{question}
        
        请分析这个问题是否涉及到数据库描述中提到的隐私信息，注意：只有描述中提到的是隐私信息，只要不涉及描述提到的隐私信息就不涉及隐私。。
        如果涉及隐私，请以JSON格式返回：
        {{
            "involves_privacy": true,
            "privacy_parts": ["涉及的隐私部分1", "涉及的隐私部分2"],
            "reason": "详细说明为什么涉及隐私"
        }}
        
        如果不涉及隐私，请返回：
        {{
            "involves_privacy": false
        }}
        
        请确保返回的是有效的JSON格式，不要包含其他解释文字。
        """
        
        messages = [
            {"role": "system", "content": "你是一个数据隐私保护专家。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": privacy_prompt}
        ]
        
        response_content = call_llm_api(messages)
        
        # 尝试解析JSON，如果失败则尝试提取JSON部分
        try:
            result = json.loads(response_content)
        except json.JSONDecodeError:
            # 尝试从响应中提取JSON部分
            import re
            json_match = re.search(r'\{[^{}]*\}', response_content, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
            else:
                # 如果无法解析，返回默认的不涉及隐私的响应
                result = {"involves_privacy": False}
        
        # 如果是RAG模式，添加选择的数据库信息
        if selected_db_info:
            result['selected_database'] = selected_db_info
        
        return jsonify(result)
        
    except Exception as e:
        print(f"隐私检查错误: {str(e)}")  # 用于调试
        return jsonify({'error': f'隐私检查失败: {str(e)}'}), 500

@app.route('/generate_sql', methods=['POST'])
def generate_sql():
    """生成SQL查询"""
    try:
        data = request.json
        question = data.get('question', '')
        db_id = data.get('db_id', '')
        
        # 如果是自动选择模式，使用RAG选择数据库
        if db_id == 'auto' or db_id is None:
            db_id, selection_reason = select_database_by_rag(question)
            if not db_id:
                return jsonify({'error': '无法选择合适的数据库'}), 404
        else:
            if db_id not in databases:
                return jsonify({'error': '数据库不存在'}), 404
        
        db_info = databases[db_id]
        
        # 获取数据库schema
        conn = sqlite3.connect(db_info['filepath'])
        cursor = conn.cursor()
        
        schema_info = []
        for table in db_info['tables']:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = cursor.fetchall()
            column_info = []
            for col in columns:
                col_name = col[1]
                col_type = col[2]
                is_pk = col[5]
                pk_info = " (PRIMARY KEY)" if is_pk else ""
                column_info.append(f"{col_name} {col_type}{pk_info}")
            schema_info.append(f"表 {table}: {', '.join(column_info)}")
            
            # 获取一些示例数据来帮助理解表结构
            try:
                cursor.execute(f"SELECT * FROM {table} LIMIT 3")
                sample_data = cursor.fetchall()
                if sample_data:
                    schema_info.append(f"  示例数据: {sample_data[0]}")
            except:
                pass
        
        conn.close()
        
        # 构建SQL生成的prompt
        sql_prompt = f"""
        数据库Schema信息：
        {chr(10).join(schema_info)}
        
        数据库描述：
        {db_info['description']}
        
        用户问题：{question}
        
        请生成一个SQL查询来回答这个问题。
        要求：
        1. 只返回SQL语句，不要其他解释
        2. SQL必须是有效的SQLite语法
        3. 确保表名和列名准确
        4. 只使用SELECT语句
        """
        
        messages = [
            {"role": "system", "content": "你是一个SQL专家。请根据提供的数据库schema生成准确的SQL查询。只返回SQL语句本身，不要包含任何解释或markdown标记。"},
            {"role": "user", "content": sql_prompt}
        ]
        
        sql = call_llm_api(messages)
        
        # 清理SQL（移除可能的markdown标记和多余空白）
        sql = sql.strip()
        sql = sql.replace('```sql', '').replace('```', '').strip()
        
        # 确保是SELECT语句
        if not sql.upper().startswith('SELECT'):
            # 尝试提取SELECT语句
            import re
            select_match = re.search(r'SELECT\s+.*?(?:;|$)', sql, re.IGNORECASE | re.DOTALL)
            if select_match:
                sql = select_match.group().strip()
            else:
                return jsonify({'error': '生成的不是有效的SELECT语句'}), 400
        
        return jsonify({
            'success': True,
            'sql': sql,
            'selected_db_id': db_id  # 返回实际使用的数据库ID
        })
        
    except Exception as e:
        print(f"SQL生成错误: {str(e)}")  # 用于调试
        return jsonify({'error': f'SQL生成失败: {str(e)}'}), 500

@app.route('/execute_sql', methods=['POST'])
def execute_sql():
    """执行SQL查询"""
    try:
        data = request.json
        sql = data.get('sql', '')
        db_id = data.get('db_id', '')
        
        # 如果是自动选择模式，从SQL中提取或使用之前选择的数据库
        if db_id == 'auto' or db_id is None:
            # 这里应该使用之前RAG选择的数据库ID
            # 暂时简化处理
            if not databases:
                return jsonify({'error': '没有可用的数据库'}), 404
            db_id = list(databases.keys())[0]
        else:
            if db_id not in databases:
                return jsonify({'error': '数据库不存在'}), 404
        
        db_info = databases[db_id]
        
        # 安全检查：只允许SELECT语句
        if not sql.strip().upper().startswith('SELECT'):
            return jsonify({'error': '只允许执行SELECT查询'}), 400
        
        # 检查是否包含危险操作
        dangerous_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'CREATE', 'ALTER', 'TRUNCATE']
        sql_upper = sql.upper()
        for keyword in dangerous_keywords:
            if keyword in sql_upper:
                return jsonify({'error': f'SQL包含不允许的操作: {keyword}'}), 400
        
        conn = sqlite3.connect(db_info['filepath'])
        cursor = conn.cursor()
        
        try:
            cursor.execute(sql)
            columns = [description[0] for description in cursor.description] if cursor.description else []
            results = cursor.fetchall()
            
            # 限制返回的行数，防止数据量过大
            max_rows = 1000
            if len(results) > max_rows:
                results = results[:max_rows]
                truncated = True
            else:
                truncated = False
            
            conn.close()
            
            response = {
                'success': True,
                'columns': columns,
                'results': results,
                'row_count': len(results)
            }
            
            if truncated:
                response['message'] = f'结果已截断，只显示前{max_rows}行'
            
            return jsonify(response)
            
        except sqlite3.Error as e:
            conn.close()
            return jsonify({'error': f'SQL执行错误: {str(e)}'}), 400
        
    except Exception as e:
        return jsonify({'error': f'执行SQL时出错: {str(e)}'}), 500

@app.route('/api_status', methods=['GET'])
def api_status():
    """检查API状态"""
    try:
        # 测试API连接
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say 'OK' if you can hear me."}
        ]
        response = call_llm_api(messages)
        return jsonify({
            'status': 'connected',
            'api_type': API_CONFIG['api_type'],
            'model': API_CONFIG['model']
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

if __name__ == '__main__':
    # 创建必要的文件夹
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # 应用启动时加载已有的数据库信息
    print("正在加载已有的数据库信息...")
    load_databases_metadata()
    
    # 扫描并修复可能丢失的数据库
    print("正在扫描和修复数据库...")
    scan_and_repair_databases()
    
    print(f"\n使用API配置:")
    print(f"  API类型: {API_CONFIG['api_type']}")
    print(f"  模型: {API_CONFIG['model']}")
    print(f"  端点: {API_CONFIG['base_url']}")
    print(f"\n已加载 {len(databases)} 个数据库")
    
    app.run(debug=True, host='0.0.0.0', port=5000)