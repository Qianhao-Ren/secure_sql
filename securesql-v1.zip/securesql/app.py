from flask import Flask, render_template, request, jsonify, send_from_directory, session, redirect, url_for
from flask_cors import CORS
import sqlite3
import os
import requests
import json
import uuid
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import secrets
from functools import wraps
from datetime import datetime

app = Flask(__name__)
CORS(app)

# 配置
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['DB_METADATA_FILE'] = 'databases_metadata.json'
app.config['USERS_DB'] = 'users.db'  # 用户数据库
app.secret_key = secrets.token_hex(16)

# 确保必要的文件夹存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('static', exist_ok=True)

# 存储数据库信息
databases = {}

# API配置
API_CONFIG = {
    'api_type': 'lixiang',
    'model': 'azure-gpt-4_1',
    'base_url': 'https://chatgpt-o1-api.dev.fc.chj.cloud/v1/chat/completions',
    'api_key': os.getenv('API_KEY', 'YOUR_API_KEY'),
    'max_tokens': 8192,
    'temperature': 0.5
}

# 用户角色定义
USER_ROLES = {
    'admin': '管理员',
    'user': '普通用户'
}

def init_users_db():
    """初始化用户数据库"""
    conn = sqlite3.connect(app.config['USERS_DB'])
    cursor = conn.cursor()
    
    # 创建用户表
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # 创建默认管理员账户（如果不存在）
    cursor.execute("SELECT * FROM users WHERE username = ?", ('admin',))
    if not cursor.fetchone():
        admin_password_hash = generate_password_hash('admin123')
        cursor.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            ('admin', admin_password_hash, 'admin')
        )
        print("创建默认管理员账户: admin / admin123")
    
    conn.commit()
    conn.close()

def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.is_json:
                return jsonify({'error': '请先登录'}), 401
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def save_databases_metadata():
    """保存数据库元信息到文件"""
    try:
        # 确保只保存必要的信息，避免循环引用
        metadata_to_save = {}
        for db_id, info in databases.items():
            metadata_to_save[db_id] = {
                'name': info.get('name', ''),
                'filename': info.get('filename', ''),
                'filepath': info.get('filepath', ''),
                'description': info.get('description', ''),
                'tables': info.get('tables', []),
                'owner_id': info.get('owner_id', 1),
                'owner_name': info.get('owner_name', 'admin'),
                'visibility': info.get('visibility', 'public'),
                'created_at': info.get('created_at', datetime.now().isoformat())
            }
        
        # 保存到文件
        with open(app.config['DB_METADATA_FILE'], 'w', encoding='utf-8') as f:
            json.dump(metadata_to_save, f, ensure_ascii=False, indent=2)
        
        print(f"成功保存 {len(metadata_to_save)} 个数据库的元信息")
        return True
        
    except Exception as e:
        print(f"保存数据库元信息失败: {str(e)}")
        return False

def load_databases_metadata():
    """从文件加载数据库元信息"""
    global databases
    try:
        # 首先清空现有数据
        databases = {}
        
        if os.path.exists(app.config['DB_METADATA_FILE']):
            with open(app.config['DB_METADATA_FILE'], 'r', encoding='utf-8') as f:
                loaded_data = json.load(f)
                
            # 验证每个数据库文件是否仍然存在
            valid_count = 0
            for db_id, info in loaded_data.items():
                filepath = info.get('filepath', '')
                if filepath and os.path.exists(filepath):
                    databases[db_id] = info
                    valid_count += 1
                else:
                    print(f"数据库文件不存在，跳过: {info.get('filename', 'unknown')}")
            
            print(f"成功加载 {valid_count} 个有效数据库（共 {len(loaded_data)} 个记录）")
            
            # 如果有无效的数据库被移除，重新保存
            if valid_count < len(loaded_data):
                save_databases_metadata()
        else:
            print("数据库元信息文件不存在，将创建新文件")
            databases = {}
            # 创建一个空的元数据文件
            save_databases_metadata()
            
    except json.JSONDecodeError as e:
        print(f"元信息文件格式错误: {str(e)}")
        databases = {}
        # 备份损坏的文件
        if os.path.exists(app.config['DB_METADATA_FILE']):
            backup_file = f"{app.config['DB_METADATA_FILE']}.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            os.rename(app.config['DB_METADATA_FILE'], backup_file)
            print(f"已备份损坏的文件到: {backup_file}")
    except Exception as e:
        print(f"加载数据库元信息失败: {str(e)}")
        databases = {}

def get_visible_databases(user_id, user_role):
    """获取当前用户可见的数据库"""
    visible_dbs = {}
    
    # 确保 user_id 是整数类型，用于比较
    try:
        user_id_int = int(user_id)
    except:
        user_id_int = user_id
    
    for db_id, db_info in databases.items():
        # 获取数据库的 owner_id，确保是整数类型
        try:
            db_owner_id = int(db_info.get('owner_id', 0))
        except:
            db_owner_id = db_info.get('owner_id', 0)
        
        # 管理员可以看到所有数据库
        if user_role == 'admin':
            visible_dbs[db_id] = db_info
        # 公开数据库所有人可见
        elif db_info.get('visibility', 'public') == 'public':
            visible_dbs[db_id] = db_info
        # 私有数据库只有所有者可见
        elif db_owner_id == user_id_int:
            visible_dbs[db_id] = db_info
    
    # 调试输出
    print(f"用户 {user_id} (角色: {user_role}) 可见的数据库数量: {len(visible_dbs)}")
    print(f"总数据库数量: {len(databases)}")
    
    return visible_dbs

def scan_and_repair_databases():
    """扫描uploads文件夹，修复可能丢失的数据库信息"""
    try:
        if not os.path.exists(app.config['UPLOAD_FOLDER']):
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            return
        
        # 获取所有已知的文件路径
        known_files = {info['filepath'] for info in databases.values() if 'filepath' in info}
        
        # 扫描uploads文件夹中的所有.db文件
        repaired_count = 0
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            if filename.endswith(('.db', '.sqlite', '.sqlite3')):
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                # 如果这个文件不在已知数据库中
                if filepath not in known_files:
                    try:
                        # 验证是否为有效的SQLite数据库
                        conn = sqlite3.connect(filepath)
                        cursor = conn.cursor()
                        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                        tables = cursor.fetchall()
                        conn.close()
                        
                        if tables:  # 只有包含表的才认为是有效数据库
                            # 尝试从文件名提取或生成ID
                            if '_' in filename and len(filename.split('_')[0]) == 36:
                                db_id = filename.split('_')[0]
                            else:
                                db_id = str(uuid.uuid4())
                            
                            # 确保ID唯一
                            while db_id in databases:
                                db_id = str(uuid.uuid4())
                            
                            # 添加到数据库列表
                            databases[db_id] = {
                                'name': filename.replace('.db', '').replace('.sqlite', '').replace('.sqlite3', ''),
                                'filename': filename,
                                'filepath': filepath,
                                'description': '自动恢复的数据库\n\n隐私信息：\n未设置隐私信息',
                                'tables': [table[0] for table in tables],
                                'owner_id': 1,  # 默认管理员ID
                                'owner_name': 'admin',
                                'visibility': 'public',
                                'created_at': datetime.fromtimestamp(os.path.getctime(filepath)).isoformat()
                            }
                            repaired_count += 1
                            print(f"恢复数据库: {filename}")
                        
                    except Exception as e:
                        print(f"无法恢复数据库 {filename}: {str(e)}")
        
        # 如果有恢复的数据库，保存元信息
        if repaired_count > 0:
            save_databases_metadata()
            print(f"共恢复 {repaired_count} 个数据库")
            
    except Exception as e:
        print(f"扫描数据库失败: {str(e)}")

def call_llm_api(messages):
    """调用LLM API"""
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {API_CONFIG["api_key"]}'
    }
    
    data = {
        'model': API_CONFIG['model'],
        'messages': messages,
        'temperature': API_CONFIG['temperature'],
        'max_tokens': API_CONFIG['max_tokens']
    }
    
    try:
        response = requests.post(
            API_CONFIG['base_url'],
            headers=headers,
            json=data,
            timeout=30
        )
        response.raise_for_status()
        
        result = response.json()
        return result['choices'][0]['message']['content']
    except requests.exceptions.RequestException as e:
        raise Exception(f"API调用失败: {str(e)}")

def select_database_by_rag(question, user_id, user_role):
    """使用RAG选择最合适的数据库，只从用户可见的数据库中选择"""
    visible_dbs = get_visible_databases(user_id, user_role)
    
    if not visible_dbs:
        return None, "没有可访问的数据库"
    
    # 构建数据库信息列表
    db_info_list = []
    for db_id, info in visible_dbs.items():
        db_info_list.append({
            'id': db_id,
            'name': info.get('name', info['filename']),
            'filename': info['filename'],
            'description': info.get('description', ''),
            'tables': info['tables'],
            'visibility': info.get('visibility', 'public'),
            'owner': info.get('owner_name', 'unknown')
        })
    
    # 构建RAG选择prompt
    rag_prompt = f"""
    用户问题：{question}
    
    可用的数据库列表：
    {json.dumps(db_info_list, ensure_ascii=False, indent=2)}
    
    请根据用户的问题，选择最适合回答该问题的数据库。
    
    选择时只考虑：
    1. 数据库名称和描述与问题的相关性
    2. 数据库包含的表是否可能包含回答问题所需的数据
    3. 问题中提到的实体、概念是否与数据库内容匹配
    
    请以JSON格式返回：
    {{
        "selected_db_id": "选中的数据库ID",
        "reason": "选择该数据库的原因"
    }}
    
    如果没有合适的数据库，返回：
    {{
        "selected_db_id": null,
        "reason": "没有找到适合回答该问题的数据库"
    }}
    """
    
    try:
        messages = [
            {"role": "system", "content": "你是一个数据库选择专家，能够根据用户问题选择最相关的数据库。"},
            {"role": "user", "content": rag_prompt}
        ]
        
        response_content = call_llm_api(messages)
        
        # 解析响应
        try:
            result = json.loads(response_content)
        except json.JSONDecodeError:
            import re
            json_match = re.search(r'\{.*?\}', response_content, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
            else:
                # 如果无法解析，选择第一个数据库
                result = {
                    "selected_db_id": list(visible_dbs.keys())[0],
                    "reason": "自动选择第一个数据库"
                }
        
        selected_db_id = result.get('selected_db_id')
        reason = result.get('reason', '')
        
        # 验证选择的数据库是否在可见列表中
        if selected_db_id and selected_db_id in visible_dbs:
            return selected_db_id, reason
        else:
            # 如果选择的数据库不可见，返回第一个
            return list(visible_dbs.keys())[0] if visible_dbs else None, "默认选择第一个可访问的数据库"
            
    except Exception as e:
        print(f"RAG选择错误: {str(e)}")
        # 出错时返回第一个数据库
        return list(visible_dbs.keys())[0] if visible_dbs else None, f"RAG选择出错: {str(e)}"

# 路由定义

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/api/login', methods=['POST'])
def api_login():
    """用户登录API"""
    try:
        data = request.json
        username = data.get('username', '')
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'error': '用户名和密码不能为空'}), 400
        
        conn = sqlite3.connect(app.config['USERS_DB'])
        cursor = conn.cursor()
        cursor.execute(
            "SELECT id, username, password_hash, role FROM users WHERE username = ?",
            (username,)
        )
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['user_role'] = user[3]
            
            return jsonify({
                'success': True,
                'user': {
                    'id': user[0],
                    'username': user[1],
                    'role': user[3]
                }
            })
        else:
            return jsonify({'error': '用户名或密码错误'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/register', methods=['POST'])
def api_register():
    """用户注册API"""
    try:
        data = request.json
        username = data.get('username', '')
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'error': '用户名和密码不能为空'}), 400
        
        if len(password) < 6:
            return jsonify({'error': '密码长度至少6位'}), 400
        
        conn = sqlite3.connect(app.config['USERS_DB'])
        cursor = conn.cursor()
        
        # 检查用户名是否已存在
        cursor.execute("SELECT id FROM users WHERE username = ?", (username,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': '用户名已存在'}), 400
        
        # 创建新用户
        password_hash = generate_password_hash(password)
        cursor.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, password_hash, 'user')
        )
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # 自动登录
        session['user_id'] = user_id
        session['username'] = username
        session['user_role'] = 'user'
        
        return jsonify({
            'success': True,
            'user': {
                'id': user_id,
                'username': username,
                'role': 'user'
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """用户登出API"""
    session.clear()
    return jsonify({'success': True})

@app.route('/api/current_user', methods=['GET'])
@login_required
def get_current_user():
    """获取当前登录用户信息"""
    return jsonify({
        'user': {
            'id': session['user_id'],
            'username': session['username'],
            'role': session['user_role']
        }
    })

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

# 修改上传函数，确保保存成功
@app.route('/upload', methods=['POST'])
@login_required
def upload_database():
    """上传数据库文件和描述文本"""
    try:
        if 'database' not in request.files:
            return jsonify({'error': '没有找到数据库文件'}), 400
        
        db_file = request.files['database']
        name = request.form.get('name', '')
        description = request.form.get('description', '')
        visibility = request.form.get('visibility', 'public')
        
        if db_file.filename == '':
            return jsonify({'error': '没有选择文件'}), 400
        
        # 生成唯一ID
        db_id = str(uuid.uuid4())
        
        # 保存文件
        filename = secure_filename(db_file.filename)
        # 保持原始扩展名
        file_ext = os.path.splitext(filename)[1] if '.' in filename else '.db'
        safe_filename = f"{db_id}_{secure_filename(name) if name else 'database'}{file_ext}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)
        
        # 确保上传目录存在
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        
        # 保存文件
        db_file.save(filepath)
        
        # 验证是否为有效的SQLite数据库
        try:
            conn = sqlite3.connect(filepath)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            tables = cursor.fetchall()
            conn.close()
            
            if not tables:
                os.remove(filepath)
                return jsonify({'error': '数据库文件中没有找到任何表'}), 400
                
        except Exception as e:
            if os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'error': f'无效的SQLite数据库文件: {str(e)}'}), 400
        
        # 存储数据库信息
        databases[db_id] = {
            'name': name if name else filename,
            'filename': filename,
            'filepath': filepath,
            'description': description,
            'tables': [table[0] for table in tables],
            'owner_id': session['user_id'],
            'owner_name': session['username'],
            'visibility': visibility,
            'created_at': datetime.now().isoformat()
        }
        
        # 立即保存元信息到文件
        if save_databases_metadata():
            print(f"数据库 {name} 上传成功，ID: {db_id}")
            
            return jsonify({
                'success': True,
                'db_id': db_id,
                'name': databases[db_id]['name'],
                'filename': filename,
                'tables': databases[db_id]['tables']
            })
        else:
            # 如果保存失败，删除上传的文件
            if os.path.exists(filepath):
                os.remove(filepath)
            if db_id in databases:
                del databases[db_id]
            return jsonify({'error': '保存数据库信息失败'}), 500
        
    except Exception as e:
        print(f"上传数据库时发生错误: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/databases', methods=['GET'])
@login_required
def list_databases():
    """列出当前用户可见的数据库"""
    visible_dbs = get_visible_databases(session['user_id'], session['user_role'])
    
    db_list = []
    for db_id, info in visible_dbs.items():
        db_list.append({
            'id': db_id,
            'name': info.get('name', info['filename']),
            'filename': info['filename'],
            'description': info.get('description', ''),
            'tables': info['tables'],
            'owner': info.get('owner_name', 'unknown'),
            'visibility': info.get('visibility', 'public'),
            'is_owner': info.get('owner_id') == session['user_id'],
            'created_at': info.get('created_at', '')
        })
    
    return jsonify(db_list)

@app.route('/database/<db_id>', methods=['DELETE'])
@login_required
def delete_database(db_id):
    """删除数据库（只能删除自己的或管理员可删除所有）"""
    try:
        if db_id not in databases:
            return jsonify({'error': '数据库不存在'}), 404
        
        db_info = databases[db_id]
        
        # 权限检查：只能删除自己的数据库，管理员可以删除所有
        if session['user_role'] != 'admin' and db_info.get('owner_id') != session['user_id']:
            return jsonify({'error': '无权删除此数据库'}), 403
        
        # 删除文件
        filepath = db_info['filepath']
        if os.path.exists(filepath):
            os.remove(filepath)
        
        # 从内存中删除
        del databases[db_id]
        
        # 保存更新后的元信息
        save_databases_metadata()
        
        return '', 204
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/check_privacy', methods=['POST'])
@login_required
def check_privacy():
    """检查问题是否涉及隐私（考虑用户权限）"""
    try:
        data = request.json
        question = data.get('question', '')
        db_id = data.get('db_id', '')
        user_role = session['user_role']
        user_id = session['user_id']
        
        # 如果是自动选择模式，使用RAG选择数据库
        if db_id == 'auto' or db_id is None:
            db_id, selection_reason = select_database_by_rag(question, user_id, user_role)
            if not db_id:
                return jsonify({'error': '无法选择合适的数据库'}), 404
            
            # 存储选择的数据库ID到session
            session['rag_selected_db_id'] = db_id
            
            # 在响应中包含选择的数据库信息
            selected_db_info = {
                'selected_db_id': db_id,
                'selected_db_name': databases[db_id].get('name', databases[db_id]['filename']),
                'selection_reason': selection_reason
            }
        else:
            # 检查用户是否有权访问该数据库
            visible_dbs = get_visible_databases(user_id, user_role)
            if db_id not in visible_dbs:
                return jsonify({'error': '无权访问该数据库'}), 403
                
            # 清除之前的RAG选择
            session.pop('rag_selected_db_id', None)
            selected_db_info = None
        
        db_info = databases[db_id]
        
        # 构建隐私检查的prompt，考虑用户角色
        privacy_prompt = f"""
        数据库描述和隐私信息：
        {db_info['description']}
        
        用户问题：{question}
        用户角色：{USER_ROLES.get(user_role, user_role)}
        
        这是一个{USER_ROLES.get(user_role, user_role)}对已选定数据库的查询问题。
        请分析这个问题是否涉及到数据库描述中明确提到的隐私信息。
        
        注意：
        1. 只有当数据库描述中明确标注为隐私信息的内容才算隐私信息
        2. 要考虑用户角色，如果描述中说"对XX用户是隐私的"，要判断当前用户是否属于该类别
        3. 如果没有明确说明对哪类用户是隐私的，则认为对除管理员外的所有用户都是隐私的
        4. 管理员（admin）有权访问所有数据，不受隐私限制
        
        如果涉及隐私，请以JSON格式返回：
        {{
            "involves_privacy": true,
            "privacy_parts": ["涉及的隐私部分1", "涉及的隐私部分2"],
            "reason": "详细说明为什么涉及隐私，以及对当前用户角色的影响"
        }}
        
        如果不涉及隐私或当前用户有权访问，请返回：
        {{
            "involves_privacy": false,
            "reason": "不涉及隐私或用户有权访问的原因"
        }}
        """
        
        messages = [
            {"role": "system", "content": "你是一个数据隐私保护专家。请严格按照要求的JSON格式返回结果。"},
            {"role": "user", "content": privacy_prompt}
        ]
        
        response_content = call_llm_api(messages)
        
        # 尝试解析JSON
        try:
            result = json.loads(response_content)
        except json.JSONDecodeError:
            import re
            json_match = re.search(r'\{[^{}]*\}', response_content, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
            else:
                result = {"involves_privacy": False, "reason": "无法解析隐私检查结果"}
        
        # 如果是管理员，强制允许访问
        if user_role == 'admin':
            result['involves_privacy'] = False
            result['reason'] = "管理员拥有全部数据访问权限"
        
        # 如果是RAG模式，添加选择的数据库信息
        if selected_db_info:
            result['selected_database'] = selected_db_info
        
        return jsonify(result)
        
    except Exception as e:
        print(f"隐私检查错误: {str(e)}")
        return jsonify({'error': f'隐私检查失败: {str(e)}'}), 500

@app.route('/generate_sql', methods=['POST'])
@login_required
def generate_sql():
    """生成SQL查询"""
    try:
        data = request.json
        question = data.get('question', '')
        db_id = data.get('db_id', '')
        user_id = session['user_id']
        user_role = session['user_role']
        
        # 如果是自动选择模式，使用RAG选择数据库
        if db_id == 'auto' or db_id is None:
            # 首先尝试从session获取之前选择的数据库
            db_id = session.get('rag_selected_db_id')
            if not db_id:
                # 如果session中没有，重新选择
                db_id, selection_reason = select_database_by_rag(question, user_id, user_role)
                if not db_id:
                    return jsonify({'error': '无法选择合适的数据库'}), 404
                # 存储到session
                session['rag_selected_db_id'] = db_id
        else:
            # 检查用户是否有权访问该数据库
            visible_dbs = get_visible_databases(user_id, user_role)
            if db_id not in visible_dbs:
                return jsonify({'error': '无权访问该数据库'}), 403
                
            # 清除之前的RAG选择
            session.pop('rag_selected_db_id', None)
        
        db_info = databases[db_id]
        
        # 获取数据库schema
        conn = sqlite3.connect(db_info['filepath'])
        cursor = conn.cursor()
        
        schema_info = []
        for table in db_info['tables']:
            cursor.execute(f"PRAGMA table_info({table})")
            columns = cursor.fetchall()
            column_info = []
            for col in columns:
                col_name = col[1]
                col_type = col[2]
                is_pk = col[5]
                pk_info = " (PRIMARY KEY)" if is_pk else ""
                column_info.append(f"{col_name} {col_type}{pk_info}")
            schema_info.append(f"表 {table}: {', '.join(column_info)}")
            
            # 获取一些示例数据来帮助理解表结构
            try:
                cursor.execute(f"SELECT * FROM {table} LIMIT 3")
                sample_data = cursor.fetchall()
                if sample_data:
                    schema_info.append(f"  示例数据: {sample_data[0]}")
            except:
                pass
        
        conn.close()
        
        # 构建SQL生成的prompt
        sql_prompt = f"""
        数据库Schema信息：
        {chr(10).join(schema_info)}
        
        数据库描述：
        {db_info['description']}
        
        用户问题：{question}
        
        请生成一个SQL查询来回答这个问题。
        要求：
        1. 只返回SQL语句，不要其他解释
        2. SQL必须是有效的SQLite语法
        3. 确保表名和列名准确
        4. 只使用SELECT语句
        """
        
        messages = [
            {"role": "system", "content": "你是一个SQL专家。请根据提供的数据库schema生成准确的SQL查询。只返回SQL语句本身。"},
            {"role": "user", "content": sql_prompt}
        ]
        
        sql = call_llm_api(messages)
        
        # 清理SQL
        sql = sql.strip()
        sql = sql.replace('```sql', '').replace('```', '').strip()
        
        # 确保是SELECT语句
        if not sql.upper().startswith('SELECT'):
            import re
            select_match = re.search(r'SELECT\s+.*?(?:;|$)', sql, re.IGNORECASE | re.DOTALL)
            if select_match:
                sql = select_match.group().strip()
            else:
                return jsonify({'error': '生成的不是有效的SELECT语句'}), 400
        
        return jsonify({
            'success': True,
            'sql': sql,
            'selected_db_id': db_id
        })
        
    except Exception as e:
        print(f"SQL生成错误: {str(e)}")
        return jsonify({'error': f'SQL生成失败: {str(e)}'}), 500

@app.route('/execute_sql', methods=['POST'])
@login_required
def execute_sql():
    """执行SQL查询"""
    try:
        data = request.json
        sql = data.get('sql', '')
        db_id = data.get('db_id', '')
        user_id = session['user_id']
        user_role = session['user_role']
        
        # 如果是自动选择模式，使用之前RAG选择的数据库
        if db_id == 'auto' or db_id is None:
            db_id = session.get('rag_selected_db_id')
            if not db_id:
                visible_dbs = get_visible_databases(user_id, user_role)
                if not visible_dbs:
                    return jsonify({'error': '没有可访问的数据库'}), 404
                db_id, _ = select_database_by_rag(f"执行SQL: {sql}", user_id, user_role)
                if not db_id:
                    db_id = list(visible_dbs.keys())[0]
        else:
            # 检查用户是否有权访问该数据库
            visible_dbs = get_visible_databases(user_id, user_role)
            if db_id not in visible_dbs:
                return jsonify({'error': '无权访问该数据库'}), 403
        
        db_info = databases[db_id]
        
        # 安全检查：只允许SELECT语句
        if not sql.strip().upper().startswith('SELECT'):
            return jsonify({'error': '只允许执行SELECT查询'}), 400
        
        # 检查是否包含危险操作
        dangerous_keywords = ['DROP', 'DELETE', 'UPDATE', 'INSERT', 'CREATE', 'ALTER', 'TRUNCATE']
        sql_upper = sql.upper()
        for keyword in dangerous_keywords:
            if keyword in sql_upper:
                return jsonify({'error': f'SQL包含不允许的操作: {keyword}'}), 400
        
        conn = sqlite3.connect(db_info['filepath'])
        cursor = conn.cursor()
        
        try:
            cursor.execute(sql)
            columns = [description[0] for description in cursor.description] if cursor.description else []
            results = cursor.fetchall()
            
            # 限制返回的行数
            max_rows = 1000
            if len(results) > max_rows:
                results = results[:max_rows]
                truncated = True
            else:
                truncated = False
            
            conn.close()
            
            response = {
                'success': True,
                'columns': columns,
                'results': results,
                'row_count': len(results)
            }
            
            if truncated:
                response['message'] = f'结果已截断，只显示前{max_rows}行'
            
            return jsonify(response)
            
        except sqlite3.Error as e:
            conn.close()
            return jsonify({'error': f'SQL执行错误: {str(e)}'}), 400
        
    except Exception as e:
        return jsonify({'error': f'执行SQL时出错: {str(e)}'}), 500

@app.route('/api_status', methods=['GET'])
def api_status():
    """检查API状态"""
    try:
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Say 'OK' if you can hear me."}
        ]
        response = call_llm_api(messages)
        return jsonify({
            'status': 'connected',
            'api_type': API_CONFIG['api_type'],
            'model': API_CONFIG['model']
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'error': str(e)
        }), 500

# 在主程序启动时的初始化顺序很重要
if __name__ == '__main__':
    # 创建必要的文件夹
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs('static', exist_ok=True)
    
    # 初始化用户数据库
    print("初始化用户数据库...")
    init_users_db()
    
    # 先加载已有的数据库信息
    print("正在加载已有的数据库信息...")
    load_databases_metadata()
    
    # 然后扫描并修复可能丢失的数据库
    print("正在扫描和修复数据库...")
    scan_and_repair_databases()
    
    print(f"\n使用API配置:")
    print(f"  API类型: {API_CONFIG['api_type']}")
    print(f"  模型: {API_CONFIG['model']}")
    print(f"  端点: {API_CONFIG['base_url']}")
    print(f"\n已加载 {len(databases)} 个数据库")
    print(f"元数据文件: {app.config['DB_METADATA_FILE']}")
    print("\n默认管理员账户: admin / admin123")
    
    app.run(debug=True, host='0.0.0.0', port=5000)